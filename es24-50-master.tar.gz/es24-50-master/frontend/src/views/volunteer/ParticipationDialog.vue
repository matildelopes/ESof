<template>
  <v-dialog v-model="dialog" persistent width="1300">
    <v-card>
      <v-card-title>
          <span class="headline">
            {{
              'New Participation'
            }}
          </span>
      </v-card-title>
      <v-card-text>
        <v-form ref="form" lazy-validation>
          <v-row>
            <v-col cols="12" sm="6" md="4">
              <v-text-field
                  label="*Rating"
                  :rules="reviewRules"
                  required
                  v-model="editParticipation.rating"
                  data-cy="ratingInput"
              ></v-text-field>
            </v-col>
          </v-row>
        </v-form>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn
            color="blue-darken-1"
            variant="text"
            @click="$emit('close-participation-dialog')"
        >
          Close
        </v-btn>
        <v-btn
            color="blue-darken-1"
            variant="text"
            @click="makeParticipation"
            data-cy="created"
        >
          Make Participant
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script lang="ts">
import { Vue, Component, Prop, Model } from 'vue-property-decorator';
import Participation from '@/models/participation/Participation';
import RemoteServices from '@/services/RemoteServices';
import Activity from '@/models/activity/Activity';


@Component({
  methods: {  },
})


export default class ParticipationDialog extends Vue {
  @Model('dialog', Boolean) dialog!: boolean;
  @Prop({ type: Participation, required: true }) readonly participation!: Participation;
  @Prop({ type: Activity, required: true }) readonly currentActivity!: Activity;


  editParticipation: Participation = new Participation();

  get reviewRules(){
    return[
      (v:number|null) => !!v || 'Please fill out your rating',
      (v:number) => v > 1 && v < 5 || 'The rating must be between 1 and 5',
    ];
  }
  async makeParticipation(){
    if ((this.$refs.form as Vue & { validate: () => boolean }).validate()) {
      try {
        const result =
            await RemoteServices.createParticipation(
                this.$store.getters.getUser.id,
                this.currentActivity.id,
                this.editParticipation,
            );
        this.$emit('save-participation', result);
      } catch (error) {
        await this.$store.dispatch('error', error);
      }
    }

  }


}
</script>

<style scoped lang="scss"></style>
