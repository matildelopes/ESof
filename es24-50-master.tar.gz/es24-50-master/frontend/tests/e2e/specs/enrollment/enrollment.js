describe('Enrollment', () => {
    beforeEach(() => {
        cy.deleteAllButArs();
        cy.createDemoEntitiesForEnrollment();
    });

    afterEach(() => {
        cy.deleteAllButArs();
    });

    it('create enrollments', () => {
        const MOTIVATION = 'I want to do it';
        cy.demoMemberLogin()
        // intercept get institutions
        cy.intercept('GET', '/users/*/getInstitution').as('getInstitutions');

        cy.get('[data-cy="institution"]').click();
        cy.get('[data-cy="activities"]').click();
        cy.wait('@getInstitutions');

        // check results
        cy.get('[data-cy="memberActivitiesTable"] tbody tr')
            .should('have.length', 3)
            .eq(0)
            .children()
            .should('have.length', 14)
        cy.get('[data-cy="memberActivitiesTable"] tbody tr')
            .eq(0).children().eq(9).should('contain', 0);
        cy.logout();

        cy.demoVolunteerLogin();
        // intercept get activities request
        cy.intercept('GET', '/activities').as('getActivities');
        // go to volunteer activities view
        cy.get('[data-cy="volunteerActivities"]').click();
        // check request was done
        cy.wait('@getActivities');

        cy.get('[data-cy="volunteerActivitiesTable"] tbody tr')
            .eq(0)
            .find('[data-cy="Apply for Activity"]')
            .click();

        cy.get('[data-cy="motivationInput"]').type(MOTIVATION);
        cy.get('[data-cy="created"]').click();
        cy.logout();

        cy.demoMemberLogin();
        cy.intercept('GET', '/users/*/getInstitution').as('getInstitution');
        cy.intercept('GET', '/themes/availableThemes').as('getThemes');

        cy.get('[data-cy="institution"]').click();
        cy.get('[data-cy="activities"]').click();
        cy.wait('@getInstitution');
        cy.wait('@getThemes');

        cy.get('[data-cy="memberActivitiesTable"] tbody tr')
            .eq(0)
            .children()
            .eq(9).should('contain', 1);
        cy.get('[data-cy="memberActivitiesTable"] tbody tr')
            .eq(0)
            .find('[data-cy="showEnrollments"]')
            .click();
        //cy.wait('@getEnrollments');
        cy.get('[data-cy="activityEnrollmentsTable"] tbody tr')
            .should('have.length', 1);
        cy.get('[data-cy="activityEnrollmentsTable"] tbody tr:first-child')
            .children()
            .eq(1).should('contain', MOTIVATION);
    });
});